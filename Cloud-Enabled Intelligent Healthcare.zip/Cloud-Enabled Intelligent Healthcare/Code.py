"""
Cloud-Enabled Intelligent Healthcare Management Using Deep Reinforcement Learning
and LSTM-Based Patient Prediction - Complete Implementation

Author: Based on Shakir Khan et al. research
Requirements: pip install numpy pandas scikit-learn tensorflow matplotlib seaborn
"""

import numpy as np
import pandas as pd
import random
import time
import warnings
from datetime import datetime, timedelta
from collections import deque
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional, Any
import json

warnings.filterwarnings('ignore')

# Deep Learning imports
import tensorflow as tf
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import LSTM, Dense, Dropout, Input
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

import matplotlib.pyplot as plt
import seaborn as sns

# Set random seeds for reproducibility
np.random.seed(42)
tf.random.set_seed(42)
random.seed(42)


@dataclass
class Patient:
    """Patient data structure"""
    patient_id: str
    age: int
    gender: str
    health_status: str  # Critical, Stable, Recovering
    disease_type: str
    heart_rate: float
    oxygen_saturation: float
    temperature: float
    timestamp: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> Dict:
        return {
            'patient_id': self.patient_id,
            'age': self.age,
            'gender': self.gender,
            'health_status': self.health_status,
            'disease_type': self.disease_type,
            'heart_rate': self.heart_rate,
            'oxygen_saturation': self.oxygen_saturation,
            'temperature': self.temperature,
            'timestamp': self.timestamp.isoformat()
        }


@dataclass
class Resource:
    """Medical resource data structure"""
    resource_id: str
    resource_type: str  # ICU_Bed, Ventilator, Medical_Staff
    is_available: bool
    patient_assigned: Optional[str] = None
    utilization_efficiency: float = 0.0


class HealthcareDataGenerator:
    """Generates synthetic IoT healthcare data for testing"""

    def __init__(self):
        self.disease_types = ['Respiratory', 'Diabetes', 'Cardiac', 'Injury', 'Other']
        self.health_statuses = ['Critical', 'Stable', 'Recovering']
        self.genders = ['Male', 'Female', 'Other']

    def generate_patient(self, patient_id: str) -> Patient:
        """Generate a single patient with realistic health metrics"""
        age = np.random.randint(18, 90)
        gender = random.choice(self.genders)
        disease_type = random.choice(self.disease_types)
        health_status = np.random.choice(self.health_statuses, p=[0.2, 0.5, 0.3])

        # Generate health metrics based on health status
        if health_status == 'Critical':
            heart_rate = np.random.uniform(100, 150)
            oxygen_saturation = np.random.uniform(70, 90)
            temperature = np.random.uniform(38.0, 40.0)
        elif health_status == 'Stable':
            heart_rate = np.random.uniform(60, 100)
            oxygen_saturation = np.random.uniform(92, 100)
            temperature = np.random.uniform(36.0, 37.5)
        else:  # Recovering
            heart_rate = np.random.uniform(65, 95)
            oxygen_saturation = np.random.uniform(94, 99)
            temperature = np.random.uniform(36.5, 37.8)

        return Patient(
            patient_id=patient_id,
            age=age,
            gender=gender,
            health_status=health_status,
            disease_type=disease_type,
            heart_rate=heart_rate,
            oxygen_saturation=oxygen_saturation,
            temperature=temperature
        )

    def generate_dataset(self, n_patients: int) -> pd.DataFrame:
        """Generate complete dataset"""
        patients = []
        for i in range(n_patients):
            patient = self.generate_patient(f"P{i + 1:04d}")
            patients.append(patient.to_dict())

        df = pd.DataFrame(patients)
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        return df


class DataPreprocessor:
    """Data preprocessing as described in the paper"""

    def __init__(self):
        self.scalers = {}
        self.label_encoders = {}

    def handle_missing_values(self, df: pd.DataFrame) -> pd.DataFrame:
        """Mean imputation for missing values"""
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            if df[col].isnull().any():
                mean_val = df[col].mean()
                df[col].fillna(mean_val, inplace=True)
        return df

    def normalize_data(self, df: pd.DataFrame, columns: List[str], fit: bool = True) -> pd.DataFrame:
        """Min-Max normalization"""
        df_norm = df.copy()
        for col in columns:
            if col in df.columns:
                if fit:
                    scaler = MinMaxScaler()
                    df_norm[col] = scaler.fit_transform(df[[col]].values).ravel()
                    self.scalers[col] = scaler
                else:
                    df_norm[col] = self.scalers[col].transform(df[[col]].values).ravel()
        return df_norm

    def encode_categorical(self, df: pd.DataFrame, columns: List[str], fit: bool = True) -> pd.DataFrame:
        """One-hot encoding for categorical variables"""
        df_encoded = df.copy()
        for col in columns:
            if col in df.columns:
                if fit:
                    encoder = LabelEncoder()
                    df_encoded[col] = encoder.fit_transform(df_encoded[col].astype(str))
                    self.label_encoders[col] = encoder
                else:
                    df_encoded[col] = self.label_encoders[col].transform(df_encoded[col].astype(str))
        return df_encoded

    def detect_outliers(self, df: pd.DataFrame, columns: List[str], threshold: float = 3) -> pd.DataFrame:
        """Z-score based outlier detection"""
        df_clean = df.copy()
        for col in columns:
            if col in df.columns:
                z_scores = np.abs((df[col] - df[col].mean()) / df[col].std())
                df_clean.loc[z_scores > threshold, col] = df[col].median()
        return df_clean

    def preprocess(self, df: pd.DataFrame, fit: bool = True) -> pd.DataFrame:
        """Complete preprocessing pipeline"""
        df = self.handle_missing_values(df)
        df = self.detect_outliers(df, ['heart_rate', 'oxygen_saturation', 'temperature', 'age'])
        df = self.encode_categorical(df, ['gender', 'disease_type', 'health_status'], fit)

        if fit:
            df = self.normalize_data(df, ['age', 'heart_rate', 'oxygen_saturation', 'temperature'], fit)

        return df


class LSTMPredictor:
    """LSTM model for patient health prediction"""

    def __init__(self, sequence_length: int = 10, n_features: int = 10):
        self.sequence_length = sequence_length
        self.n_features = n_features
        self.model = None
        self.history = None

    def create_sequences(self, data: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Create sequences for LSTM training"""
        X, y = [], []
        for i in range(len(data) - self.sequence_length - 1):
            X.append(data[i:i + self.sequence_length])
            y.append(data[i + self.sequence_length, 2])  # Health status encoded
        return np.array(X), np.array(y)

    def build_model(self) -> Sequential:
        """Build LSTM architecture"""
        model = Sequential([
            LSTM(128, return_sequences=True, input_shape=(self.sequence_length, self.n_features)),
            Dropout(0.2),
            LSTM(64, return_sequences=True),
            Dropout(0.2),
            LSTM(32),
            Dropout(0.2),
            Dense(16, activation='relu'),
            Dense(3, activation='softmax')  # 3 health status classes
        ])
        model.compile(optimizer=Adam(learning_rate=0.001),
                      loss='sparse_categorical_crossentropy',
                      metrics=['accuracy'])
        return model

    def train(self, X_train: np.ndarray, y_train: np.ndarray,
              X_val: np.ndarray, y_val: np.ndarray, epochs: int = 50) -> Dict:
        """Train LSTM model"""
        self.model = self.build_model()

        early_stopping = EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)

        self.history = self.model.fit(
            X_train, y_train,
            validation_data=(X_val, y_val),
            epochs=epochs,
            batch_size=32,
            callbacks=[early_stopping],
            verbose=1
        )

        return self.history.history

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Make predictions"""
        return self.model.predict(X)

    def predict_health_status(self, sequence: np.ndarray) -> Tuple[str, float]:
        """Predict single patient health status"""
        if len(sequence.shape) == 2:
            sequence = sequence.reshape(1, sequence.shape[0], sequence.shape[1])
        prediction = self.model.predict(sequence, verbose=0)
        predicted_class = np.argmax(prediction[0])
        confidence = np.max(prediction[0])

        status_map = {0: 'Critical', 1: 'Stable', 2: 'Recovering'}
        return status_map[predicted_class], confidence


class DeepQLearningAgent:
    """Deep Q-Learning agent for resource allocation"""

    def __init__(self, state_size: int, action_size: int, learning_rate: float = 0.001):
        self.state_size = state_size
        self.action_size = action_size
        self.memory = deque(maxlen=2000)
        self.gamma = 0.95  # discount factor
        self.epsilon = 1.0  # exploration rate
        self.epsilon_min = 0.01
        self.epsilon_decay = 0.995
        self.learning_rate = learning_rate
        self.model = self._build_model()
        self.target_model = self._build_model()
        self.update_target_model()

    def _build_model(self) -> Sequential:
        """Build DQN model"""
        model = Sequential([
            Dense(64, activation='relu', input_dim=self.state_size),
            Dense(32, activation='relu'),
            Dense(16, activation='relu'),
            Dense(self.action_size, activation='linear')
        ])
        model.compile(optimizer=Adam(learning_rate=self.learning_rate), loss='mse')
        return model

    def update_target_model(self):
        """Update target network"""
        self.target_model.set_weights(self.model.get_weights())

    def remember(self, state: np.ndarray, action: int, reward: float,
                 next_state: np.ndarray, done: bool):
        """Store experience in memory"""
        self.memory.append((state, action, reward, next_state, done))

    def act(self, state: np.ndarray, evaluate: bool = False) -> int:
        """Choose action using epsilon-greedy policy"""
        if not evaluate and np.random.rand() <= self.epsilon:
            return random.randrange(self.action_size)

        act_values = self.model.predict(state.reshape(1, -1), verbose=0)
        return np.argmax(act_values[0])

    def replay(self, batch_size: int = 32):
        """Experience replay"""
        if len(self.memory) < batch_size:
            return

        minibatch = random.sample(self.memory, batch_size)

        for state, action, reward, next_state, done in minibatch:
            target = reward
            if not done:
                target = reward + self.gamma * np.amax(
                    self.target_model.predict(next_state.reshape(1, -1), verbose=0)[0]
                )

            target_f = self.model.predict(state.reshape(1, -1), verbose=0)
            target_f[0][action] = target

            self.model.fit(state.reshape(1, -1), target_f, epochs=1, verbose=0)

        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay


class PumaAlgorithm:
    """Puma Algorithm for optimization (as described in the paper)"""

    def __init__(self, n_agents: int = 30, n_iterations: int = 100):
        self.n_agents = n_agents
        self.n_iterations = n_iterations
        self.c1 = 1.5  # cognitive coefficient
        self.c2 = 1.5  # social coefficient
        self.w = 0.7  # inertia weight

    def optimize(self, objective_func, bounds: Tuple[float, float]) -> Tuple[np.ndarray, float]:
        """
        Optimize using Puma Algorithm

        Args:
            objective_func: Function to minimize/maximize
            bounds: (lower_bound, upper_bound)
        """
        dim = 1  # single objective optimization
        lower, upper = bounds

        # Initialize population
        positions = np.random.uniform(lower, upper, (self.n_agents, dim))
        velocities = np.random.uniform(-1, 1, (self.n_agents, dim))

        # Personal best and global best
        pbest = positions.copy()
        pbest_fitness = np.array([objective_func(p) for p in positions])

        gbest_idx = np.argmin(pbest_fitness)
        gbest = pbest[gbest_idx].copy()
        gbest_fitness = pbest_fitness[gbest_idx]

        # Optimization loop
        convergence = []

        for iteration in range(self.n_iterations):
            # Update inertia weight (exploration to exploitation)
            w = self.w * (1 - iteration / self.n_iterations)

            for i in range(self.n_agents):
                # Update velocity
                r1, r2 = np.random.rand(2)
                velocities[i] = (w * velocities[i] +
                                 self.c1 * r1 * (pbest[i] - positions[i]) +
                                 self.c2 * r2 * (gbest - positions[i]))

                # Update position
                positions[i] = positions[i] + velocities[i]

                # Clip to bounds
                positions[i] = np.clip(positions[i], lower, upper)

                # Evaluate new position
                fitness = objective_func(positions[i])

                # Update personal best
                if fitness < pbest_fitness[i]:
                    pbest[i] = positions[i].copy()
                    pbest_fitness[i] = fitness

                    # Update global best
                    if fitness < gbest_fitness:
                        gbest = positions[i].copy()
                        gbest_fitness = fitness

            convergence.append(gbest_fitness)

        return gbest, gbest_fitness, convergence


class HealthcareResourceOptimizer:
    """Main framework integrating LSTM, DRL, and Puma Algorithm"""

    def __init__(self):
        self.lstm_predictor = None
        self.drl_agent = None
        self.puma_optimizer = PumaAlgorithm()
        self.preprocessor = DataPreprocessor()
        self.resources = self._initialize_resources()

        # Resource allocation history
        self.allocation_history = []

    def _initialize_resources(self) -> List[Resource]:
        """Initialize healthcare resources"""
        resources = []

        # ICU Beds
        for i in range(20):
            resources.append(Resource(
                resource_id=f"ICU_{i + 1:03d}",
                resource_type="ICU_Bed",
                is_available=True
            ))

        # Ventilators
        for i in range(15):
            resources.append(Resource(
                resource_id=f"VENT_{i + 1:03d}",
                resource_type="Ventilator",
                is_available=True
            ))

        # Medical Staff
        for i in range(30):
            resources.append(Resource(
                resource_id=f"STAFF_{i + 1:03d}",
                resource_type="Medical_Staff",
                is_available=True
            ))

        return resources

    def train_lstm_model(self, data: pd.DataFrame, sequence_length: int = 10) -> Dict:
        """Train LSTM model on healthcare data"""
        print("\n" + "=" * 60)
        print("TRAINING LSTM MODEL FOR PATIENT HEALTH PREDICTION")
        print("=" * 60)

        # Preprocess data
        processed_data = self.preprocessor.preprocess(data, fit=True)

        # Prepare features for LSTM
        feature_cols = ['age', 'heart_rate', 'oxygen_saturation', 'temperature',
                        'gender', 'disease_type']

        # Get numeric data
        feature_matrix = processed_data[feature_cols].values

        # Create sequences
        self.lstm_predictor = LSTMPredictor(sequence_length=sequence_length,
                                            n_features=len(feature_cols))

        X, y = self.lstm_predictor.create_sequences(feature_matrix)

        # Split data
        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

        print(f"Training samples: {len(X_train)}")
        print(f"Validation samples: {len(X_val)}")
        print(f"Sequence length: {sequence_length}")
        print(f"Features: {len(feature_cols)}")

        # Train model
        history = self.lstm_predictor.train(X_train, y_train, X_val, y_val, epochs=30)

        return history

    def train_drl_agent(self, n_episodes: int = 100, max_steps: int = 100):
        """Train DRL agent for resource allocation"""
        print("\n" + "=" * 60)
        print("TRAINING DEEP REINFORCEMENT LEARNING AGENT")
        print("=" * 60)

        state_size = 6  # features: n_critical, n_stable, n_recovering, available_resources, etc.
        action_size = 4  # actions: allocate_icu, allocate_vent, allocate_staff, no_action

        self.drl_agent = DeepQLearningAgent(state_size, action_size)

        episode_rewards = []

        for episode in range(n_episodes):
            state = self._get_state()
            total_reward = 0

            for step in range(max_steps):
                # Select action
                action = self.drl_agent.act(state)

                # Execute action and get reward
                next_state, reward, done = self._step_environment(action)
                total_reward += reward

                # Store experience
                self.drl_agent.remember(state, action, reward, next_state, done)

                # Train agent
                self.drl_agent.replay(batch_size=32)

                state = next_state

                if done:
                    break

            # Update target network every 10 episodes
            if episode % 10 == 0:
                self.drl_agent.update_target_model()

            episode_rewards.append(total_reward)

            if episode % 20 == 0:
                print(
                    f"Episode {episode}/{n_episodes} - Total Reward: {total_reward:.2f} - Epsilon: {self.drl_agent.epsilon:.3f}")

        return episode_rewards

    def _get_state(self) -> np.ndarray:
        """Get current state of the system"""
        n_critical = sum(1 for p in self.active_patients if p.health_status == 'Critical')
        n_stable = sum(1 for p in self.active_patients if p.health_status == 'Stable')
        n_recovering = sum(1 for p in self.active_patients if p.health_status == 'Recovering')

        available_icu = sum(1 for r in self.resources
                            if r.resource_type == 'ICU_Bed' and r.is_available)
        available_vent = sum(1 for r in self.resources
                             if r.resource_type == 'Ventilator' and r.is_available)
        available_staff = sum(1 for r in self.resources
                              if r.resource_type == 'Medical_Staff' and r.is_available)

        return np.array([n_critical, n_stable, n_recovering,
                         available_icu, available_vent, available_staff], dtype=np.float32)

    def _step_environment(self, action: int) -> Tuple[np.ndarray, float, bool]:
        """Execute action and return new state, reward, done"""
        reward = 0

        # Action mapping
        actions = {
            0: ("ICU_Bed", 5),  # allocate ICU beds (weight 5)
            1: ("Ventilator", 4),  # allocate ventilators (weight 4)
            2: ("Medical_Staff", 3),  # allocate medical staff (weight 3)
            3: ("No_Action", 0)  # no action
        }

        resource_type, weight = actions[action]

        if action != 3:  # not no_action
            # Find available resource
            for resource in self.resources:
                if resource.resource_type == resource_type and resource.is_available:
                    # Allocate to critical patient if available
                    critical_patients = [p for p in self.active_patients
                                         if p.health_status == 'Critical']
                    if critical_patients:
                        patient = critical_patients[0]
                        resource.is_available = False
                        resource.patient_assigned = patient.patient_id
                        resource.utilization_efficiency = min(1.0, weight / 10)

                        # Positive reward for allocation
                        reward += weight

                        # Additional reward for critical patient
                        if patient.health_status == 'Critical':
                            reward += 2
                    break

        # Calculate utilization efficiency
        utilization = sum(r.utilization_efficiency for r in self.resources) / len(self.resources)
        reward += utilization * 0.5

        # Penalty for low availability
        available_resources = sum(1 for r in self.resources if r.is_available)
        if available_resources < 10:
            reward -= 0.5

        done = False  # Episode continues

        return self._get_state(), reward, done

    def optimize_with_puma(self, n_patients: int) -> Dict:
        """Use Puma Algorithm to optimize resource allocation"""
        print("\n" + "=" * 60)
        print("OPTIMIZING RESOURCE ALLOCATION WITH PUMA ALGORITHM")
        print("=" * 60)

        def objective_function(x):
            """Objective to maximize resource utilization efficiency"""
            resource_utilization = x[0]
            # Maximize utilization, minimize cost
            return 1 - resource_utilization

        best_solution, best_fitness, convergence = self.puma_optimizer.optimize(
            objective_function,
            bounds=(0.5, 1.0)  # resource allocation ratio bounds
        )

        print(f"Optimal resource utilization ratio: {best_solution[0]:.4f}")
        print(f"Best fitness (1 - utilization): {best_fitness:.4f}")

        return {
            'optimal_ratio': best_solution[0],
            'best_fitness': best_fitness,
            'convergence': convergence
        }

    def predict_patient_health(self, patient_data: pd.DataFrame) -> List[Tuple[str, float]]:
        """Predict health status for patients"""
        if self.lstm_predictor is None or self.lstm_predictor.model is None:
            raise ValueError("LSTM model not trained yet!")

        processed_data = self.preprocessor.preprocess(patient_data, fit=False)

        feature_cols = ['age', 'heart_rate', 'oxygen_saturation', 'temperature',
                        'gender', 'disease_type']

        feature_matrix = processed_data[feature_cols].values

        predictions = []
        for i in range(len(feature_matrix) - self.lstm_predictor.sequence_length):
            sequence = feature_matrix[i:i + self.lstm_predictor.sequence_length]
            status, confidence = self.lstm_predictor.predict_health_status(sequence)
            predictions.append((status, confidence))

        return predictions

    def run_real_time_simulation(self, duration_seconds: int = 60,
                                 patient_arrival_rate: float = 0.5):
        """Run real-time simulation of healthcare system"""
        print("\n" + "=" * 60)
        print("REAL-TIME HEALTHCARE SYSTEM SIMULATION")
        print("=" * 60)

        self.active_patients = []
        data_generator = HealthcareDataGenerator()

        start_time = time.time()
        end_time = start_time + duration_seconds

        patient_counter = 0
        simulation_log = []

        print(f"Simulation running for {duration_seconds} seconds...")
        print("-" * 60)

        while time.time() < end_time:
            current_time = time.time() - start_time

            # Generate new patients
            if random.random() < patient_arrival_rate * 0.1:  # Adjust arrival rate
                patient_counter += 1
                new_patient = data_generator.generate_patient(f"SIM_{patient_counter:04d}")
                self.active_patients.append(new_patient)

                # Predict health status
                patient_df = pd.DataFrame([new_patient.to_dict()])
                try:
                    predictions = self.predict_patient_health(patient_df)
                    if predictions:
                        predicted_status, confidence = predictions[0]
                        print(f"[{current_time:.1f}s] NEW PATIENT: {new_patient.patient_id} | "
                              f"Age: {new_patient.age} | Health: {new_patient.health_status} | "
                              f"Predicted: {predicted_status} (conf: {confidence:.2f}) | "
                              f"HR: {new_patient.heart_rate:.0f} | SpO2: {new_patient.oxygen_saturation:.0f}")

                        simulation_log.append({
                            'timestamp': current_time,
                            'event': 'PATIENT_ARRIVAL',
                            'patient_id': new_patient.patient_id,
                            'health_status': new_patient.health_status,
                            'predicted_status': predicted_status,
                            'confidence': confidence,
                            'heart_rate': new_patient.heart_rate,
                            'oxygen_saturation': new_patient.oxygen_saturation
                        })
                except:
                    pass

            # Resource allocation decision using DRL
            if self.drl_agent:
                state = self._get_state()
                action = self.drl_agent.act(state, evaluate=True)

                if action != 3:  # not no_action
                    action_names = ['Allocate ICU Bed', 'Allocate Ventilator',
                                    'Allocate Medical Staff', 'No Action']

                    # Check for critical patients
                    critical_patients = [p for p in self.active_patients
                                         if p.health_status == 'Critical']

                    if critical_patients and action != 3:
                        print(f"[{current_time:.1f}s] ACTION: {action_names[action]} | "
                              f"Critical patients: {len(critical_patients)}")

                        simulation_log.append({
                            'timestamp': current_time,
                            'event': 'RESOURCE_ALLOCATION',
                            'action': action_names[action],
                            'critical_patients': len(critical_patients),
                            'available_resources': sum(1 for r in self.resources if r.is_available)
                        })

            # Update patient statuses
            for patient in self.active_patients[:]:
                if random.random() < 0.05:  # 5% chance of status change
                    old_status = patient.health_status
                    if patient.health_status == 'Critical':
                        patient.health_status = random.choice(['Stable', 'Recovering'])
                    elif patient.health_status == 'Stable':
                        patient.health_status = random.choice(['Critical', 'Recovering'])
                    else:
                        patient.health_status = 'Stable'

                    print(f"[{current_time:.1f}s] STATUS CHANGE: {patient.patient_id} | "
                          f"{old_status} -> {patient.health_status}")

                    simulation_log.append({
                        'timestamp': current_time,
                        'event': 'STATUS_CHANGE',
                        'patient_id': patient.patient_id,
                        'old_status': old_status,
                        'new_status': patient.health_status
                    })

            # Remove recovered patients
            self.active_patients = [p for p in self.active_patients
                                    if p.health_status != 'Recovering' or random.random() > 0.1]

            time.sleep(0.1)  # Simulation step

        print("-" * 60)
        print(f"Simulation completed. Total patients processed: {patient_counter}")

        return simulation_log


class PerformanceEvaluator:
    """Evaluate framework performance metrics"""

    def __init__(self):
        self.metrics = {}

    def calculate_metrics(self, y_true: np.ndarray, y_pred: np.ndarray) -> Dict:
        """Calculate accuracy, precision, recall, f1-score"""
        metrics = {
            'accuracy': accuracy_score(y_true, y_pred),
            'precision': precision_score(y_true, y_pred, average='weighted', zero_division=0),
            'recall': recall_score(y_true, y_pred, average='weighted', zero_division=0),
            'f1_score': f1_score(y_true, y_pred, average='weighted', zero_division=0)
        }
        return metrics

    def calculate_latency(self, execution_times: List[float]) -> Dict:
        """Calculate latency metrics"""
        return {
            'mean_latency_ms': np.mean(execution_times) * 1000,
            'min_latency_ms': np.min(execution_times) * 1000,
            'max_latency_ms': np.max(execution_times) * 1000,
            'p95_latency_ms': np.percentile(execution_times, 95) * 1000,
            'p99_latency_ms': np.percentile(execution_times, 99) * 1000
        }

    def calculate_throughput(self, n_requests: int, time_seconds: float) -> float:
        """Calculate throughput in requests per second"""
        return n_requests / time_seconds

    def calculate_cost_efficiency(self, operational_cost: float, resources_utilized: int) -> float:
        """Calculate cost efficiency"""
        return operational_cost / max(resources_utilized, 1)

    def evaluate_framework(self, framework: HealthcareResourceOptimizer,
                           test_data: pd.DataFrame) -> Dict:
        """Complete evaluation of framework"""
        print("\n" + "=" * 60)
        print("FRAMEWORK PERFORMANCE EVALUATION")
        print("=" * 60)

        # Test LSTM predictions
        if framework.lstm_predictor and framework.lstm_predictor.model:
            processed_data = framework.preprocessor.preprocess(test_data, fit=False)
            feature_cols = ['age', 'heart_rate', 'oxygen_saturation', 'temperature',
                            'gender', 'disease_type']
            feature_matrix = processed_data[feature_cols].values

            # Measure prediction latency
            latencies = []
            predictions = []
            true_labels = []

            for i in range(len(feature_matrix) - framework.lstm_predictor.sequence_length):
                start = time.time()
                sequence = feature_matrix[i:i + framework.lstm_predictor.sequence_length]
                status, _ = framework.lstm_predictor.predict_health_status(sequence)
                latencies.append(time.time() - start)

                predictions.append(status)
                true_labels.append(processed_data.iloc[i + framework.lstm_predictor.sequence_length]['health_status'])

            # Map status to numbers for metric calculation
            status_map = {'Critical': 0, 'Stable': 1, 'Recovering': 2}
            y_true = [status_map[s] for s in true_labels if s in status_map]
            y_pred = [status_map[p] for p in predictions if p in status_map]

            if len(y_true) == len(y_pred) and len(y_true) > 0:
                self.metrics['prediction'] = self.calculate_metrics(np.array(y_true), np.array(y_pred))
                self.metrics['latency'] = self.calculate_latency(latencies)

                print(f"\nPrediction Metrics:")
                print(f"  Accuracy: {self.metrics['prediction']['accuracy'] * 100:.2f}%")
                print(f"  Precision: {self.metrics['prediction']['precision'] * 100:.2f}%")
                print(f"  Recall: {self.metrics['prediction']['recall'] * 100:.2f}%")
                print(f"  F1-Score: {self.metrics['prediction']['f1_score'] * 100:.2f}%")

                print(f"\nLatency Metrics:")
                print(f"  Mean Latency: {self.metrics['latency']['mean_latency_ms']:.2f} ms")
                print(f"  P95 Latency: {self.metrics['latency']['p95_latency_ms']:.2f} ms")
                print(f"  P99 Latency: {self.metrics['latency']['p99_latency_ms']:.2f} ms")

        # Resource utilization metrics
        total_resources = len(framework.resources)
        utilized_resources = sum(1 for r in framework.resources if not r.is_available)
        self.metrics['resource_utilization'] = utilized_resources / total_resources

        print(f"\nResource Management:")
        print(f"  Total Resources: {total_resources}")
        print(f"  Utilized Resources: {utilized_resources}")
        print(f"  Utilization Rate: {self.metrics['resource_utilization'] * 100:.2f}%")

        # Cost efficiency estimation
        estimated_operational_cost = 10000  # Example operational cost
        self.metrics['cost_efficiency'] = self.calculate_cost_efficiency(
            estimated_operational_cost, utilized_resources
        )

        print(f"\nCost Efficiency:")
        print(f"  Estimated Cost per Resource: ${self.metrics['cost_efficiency']:.2f}")

        return self.metrics


def visualize_results(metrics: Dict, history: Dict, optimizer_results: Dict, simulation_log: List):
    """Create comprehensive visualization of results"""

    fig = plt.figure(figsize=(16, 12))

    # 1. Training Loss
    if 'loss' in history:
        ax1 = fig.add_subplot(3, 3, 1)
        ax1.plot(history.get('loss', []), label='Training Loss', color='blue')
        ax1.plot(history.get('val_loss', []), label='Validation Loss', color='red')
        ax1.set_xlabel('Epoch')
        ax1.set_ylabel('Loss')
        ax1.set_title('LSTM Training Loss')
        ax1.legend()
        ax1.grid(True, alpha=0.3)

    # 2. Training Accuracy
    if 'accuracy' in history:
        ax2 = fig.add_subplot(3, 3, 2)
        ax2.plot(history.get('accuracy', []), label='Training Accuracy', color='blue')
        ax2.plot(history.get('val_accuracy', []), label='Validation Accuracy', color='red')
        ax2.set_xlabel('Epoch')
        ax2.set_ylabel('Accuracy')
        ax2.set_title('LSTM Training Accuracy')
        ax2.legend()
        ax2.grid(True, alpha=0.3)